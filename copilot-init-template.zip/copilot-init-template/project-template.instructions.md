# 🚀 Template de Configuração Copilot

Este template permite configurar o GitHub Copilot otimizado para projetos específicos.

## ⚠️ IMPORTANTE: CONFIGURAÇÃO APENAS NA PASTA .vscode

**NUNCA crie arquivos na raiz do projeto!** Toda configuração deve ser feita na pasta `.vscode` para evitar commits acidentais.

## 📋 INSTRUÇÕES DE USO

### 1. Análise Inicial do Projeto

Primeiro, execute este prompt no Copilot Chat:

```
@workspace Analise este projeto completamente:
1. Examine pyproject.toml/package.json/pom.xml para identificar stack tecnológico
2. Analise estrutura de pastas para identificar padrões arquiteturais
3. Verifique Makefile/package.json/build files para comandos disponíveis
4. Identifique frameworks, bibliotecas e padrões de código
5. Forneça overview completo antes de configurar Copilot
```

### 2. Geração de Instruções Personalizadas

Com base na análise, execute:

```
@workspace Baseado na análise anterior, gere arquivo de instruções Copilot personalizado seguindo este template:

# {PROJECT_NAME} - Instruções de Desenvolvimento

## 🎯 MISSÃO E CONTEXTO
Você é especialista em {MAIN_LANGUAGE}/{MAIN_FRAMEWORK} com expertise total no projeto {PROJECT_NAME}.

## 🔍 ANÁLISE OBRIGATÓRIA INICIAL
[Preencher com comandos específicos do projeto: cat pyproject.toml, cat Makefile, etc.]

## 📋 PADRÕES DE IMPLEMENTAÇÃO
[Preencher com padrões específicos identificados no código]

## 🔧 COMANDOS E WORKFLOWS
[Preencher com comandos make/npm/etc específicos do projeto]

## 🚨 REGRAS CRÍTICAS
[Preencher com regras específicas do projeto]

SALVE em .vscode/copilot-instructions.md (NÃO na raiz!)
```

### 3. Configuração do VS Code

Execute este prompt:

```
@workspace Configure VS Code settings.json otimizado para este projeto:

1. github.copilot.chat.instructionFiles: [".vscode/copilot-instructions.md"]
2. Comandos permitidos baseados nos comandos build identificados
3. Comandos bloqueados para segurança
4. Configurações específicas da linguagem identificada
5. Context include/exclude apropriados

SALVE em .vscode/settings.json (atualizar se existir)
```

### 4. Modos de Chat Customizados

Para projetos complexos, gere modos especializados:

```
@workspace Crie modos de chat customizados para este projeto baseado na stack identificada:

Exemplos:
- project-analyzer: Para análise inicial
- [framework]-expert: Para implementação (ex: fastapi-expert, react-expert)
- test-master: Para testes específicos da stack
- security-auditor: Para review de segurança
- [database]-expert: Para queries/repositories (ex: mongodb-expert)

Configure em .vscode/settings.json dentro de github.copilot.chat.customInstructions
```

### 5. Validação Final

Execute para confirmar configuração:

```
@workspace Valide a configuração Copilot criada:
1. Verifique se .vscode/copilot-instructions.md existe e está correto
2. Verifique se .vscode/settings.json tem as configurações Copilot
3. Teste com comando simples: "Analise este projeto seguindo .vscode/copilot-instructions.md"
4. Confirme que não há arquivos criados na raiz do projeto
5. REMOVA a pasta copilot-init-template da raiz do projeto: rm -rf copilot-init-template
```

### 6. Limpeza Final (OBRIGATÓRIO)

Após configurar tudo em `.vscode/`, **SEMPRE remova a pasta template**:

```bash
# Execute este comando para limpar o projeto:
rm -rf copilot-init-template
```

**Por quê remover?**

- ✅ Projeto fica limpo sem arquivos desnecessários
- ✅ Evita commits acidentais da pasta template
- ✅ Toda configuração já está salva em `.vscode/`
- ✅ Template pode ser reutilizado em outros projetos

## 🎯 TEMPLATE DE INSTRUÇÕES PERSONALIZADAS

Use este template base para `.vscode/copilot-instructions.md`:

````instructions
# {PROJECT_NAME} - Instruções de Desenvolvimento

## 🎯 MISSÃO E CONTEXTO
Você é especialista em {MAIN_LANGUAGE}/{MAIN_FRAMEWORK} com expertise total no projeto {PROJECT_NAME}.

## 🔍 ANÁLISE OBRIGATÓRIA INICIAL

### Stack Tecnológico
```bash
# Examinar dependências
cat {DEPENDENCY_FILE}
````

### Comandos Build

```bash
# Examinar comandos disponíveis
cat {BUILD_FILE}
```

## 📋 PADRÕES DE IMPLEMENTAÇÃO

### {COMPONENT_TYPE}

```{MAIN_LANGUAGE}
// Template base identificado no projeto
{COMPONENT_TEMPLATE}
```

### Testes

```{MAIN_LANGUAGE}
// Padrão de testes identificado
{TEST_TEMPLATE}
```

## 🔧 COMANDOS E WORKFLOWS

### Desenvolvimento

```bash
{SETUP_COMMANDS}
{RUN_COMMAND}
{TEST_COMMAND}
{LINT_COMMAND}
```

## 🚨 REGRAS CRÍTICAS

### ❌ NUNCA FAÇA:

- Usar comandos diretos ao invés do {BUILD_FILE}
- Implementar sem analisar padrões existentes
- Criar arquivos na raiz sem necessidade

### ✅ SEMPRE FAÇA:

- Analisar código existente primeiro
- Seguir padrões arquiteturais identificados
- Usar comandos do {BUILD_FILE}
- Manter consistência com projeto

## 🎯 CHECKLIST PRE-IMPLEMENTAÇÃO

- [ ] Analisei dependências e stack
- [ ] Identifiquei padrões existentes
- [ ] Verifiquei comandos disponíveis
- [ ] Entendi arquitetura do projeto

---

**LEMBRE-SE**: Analise sempre o código existente antes de implementar!

````

## � TEMPLATE DE SETTINGS.JSON

Base para `.vscode/settings.json`:

```json
{
  "github.copilot.chat.instructionFiles": [".vscode/copilot-instructions.md"],

  "github.copilot.chat.agent.terminal.allowList": [
    // Comandos específicos do projeto identificados
    "{BUILD_COMMANDS}",
    "{PACKAGE_MANAGER_COMMANDS}",
    "{GIT_SAFE_COMMANDS}"
  ],

  "github.copilot.chat.agent.terminal.denyList": [
    "rm", "sudo", "curl", "wget",
    "/.*password.*/i", "/.*secret.*/i"
  ],

  "chat.tools.autoApprove": false,

  // Configurações específicas da linguagem
  "{LANGUAGE_SPECIFIC_CONFIG}": true
}
````

## ✅ VALIDAÇÃO DE CONFIGURAÇÃO

Para confirmar que tudo está correto:

1. **Verificar arquivos criados**:

   ```bash
   ls -la .vscode/
   # Deve mostrar: copilot-instructions.md, settings.json

   ls -la | grep -E "\.(md|json)$"
   # NÃO deve mostrar arquivos de configuração na raiz
   ```

2. **Testar Copilot**:

   ```
   @workspace Analise este projeto seguindo .vscode/copilot-instructions.md
   ```

3. **Verificar comandos**:
   - Comandos permitidos devem executar automaticamente
   - Comandos bloqueados devem pedir confirmação

## 🚀 PRÓXIMOS PASSOS

Após configuração:

1. **Teste básico**: Análise inicial do projeto
2. **Implementação simples**: Uma pequena feature seguindo padrões
3. **Ajustes**: Refine instruções conforme necessário
4. **Compartilhamento**: Configure para toda equipe

---

**💡 Dica**: Mantenha as instruções simples e específicas. O Copilot funciona melhor com contexto claro e objetivo.
