# 🎯 GitHub Copilot Init Template

Esta pasta contém templates para configurar o GitHub Copilot otimizado para qualquer projeto, criando configurações **APENAS na pasta .vscode** para evitar commits acidentais.

## ⚠️ PRINCÍPIO FUNDAMENTAL

**NUNCA criar arquivos na raiz do projeto!** Toda configuração deve ser feita exclusivamente na pasta `.vscode/` para evitar commits indesejados.

## 🚀 **FLUXO COMPLETO DE USO**

### 1️⃣ **Copiar Template**

```bash
# Copiar esta pasta para a raiz do novo projeto
cp -r copilot-init-template /caminho/do/novo/projeto/
```

### 2️⃣ **Configurar Copilot**

Abra o Copilot Chat (Ctrl+Alt+I) e execute:

```
@workspace Analise este projeto completamente seguindo copilot-init-template/project-template.instructions.md:
1. Identifique stack tecnológico, arquitetura e padrões
2. Configure Copilot otimizado APENAS na pasta .vscode/
3. NÃO crie arquivos na raiz do projeto
4. Valide configuração final
5. REMOVA a pasta copilot-init-template após configuração
```

### 3️⃣ **Resultado Esperado**

O Copilot vai criar **automaticamente**:

- `.vscode/copilot-instructions.md` - Instruções específicas do projeto
- `.vscode/settings.json` - Configuração otimizada do VS Code
- Remover `copilot-init-template/` da raiz

### 4️⃣ **Validação Final**

```bash
# Testar configuração:
@workspace Analise este projeto seguindo .vscode/copilot-instructions.md

# Verificar limpeza:
ls copilot-init-template/  # Deve retornar erro (pasta removida)
ls .vscode/               # Deve mostrar arquivos configurados
```

## 📁 **Estrutura Final (Limpa)**

Após configuração, o projeto deve ficar assim:

```
projeto/
├── .vscode/
│   ├── copilot-instructions.md  ✅ Criado automaticamente
│   └── settings.json            ✅ Configurado automaticamente
├── src/                         # Código do projeto
├── package.json                 # Ou pyproject.toml, pom.xml, etc.
└── ...
# ❌ copilot-init-template/      # REMOVIDO automaticamente
```

## 🎯 **Por Stack Tecnológica**

### Python/FastAPI

```
@workspace Configure Copilot para projeto Python/FastAPI seguindo copilot-init-template/project-template.instructions.md
```

### React/TypeScript

```
@workspace Configure Copilot para projeto React/TypeScript seguindo copilot-init-template/project-template.instructions.md
```

### Node.js/Express

```
@workspace Configure Copilot para projeto Node.js/Express seguindo copilot-init-template/project-template.instructions.md
```

### Java/Spring

```
@workspace Configure Copilot para projeto Java/Spring seguindo copilot-init-template/project-template.instructions.md
```

## ✅ **Vantagens desta Abordagem**

1. **🧹 Projeto limpo**: Template removido após uso
2. **📁 Configuração organizada**: Tudo em `.vscode/`
3. **🔒 Zero commits acidentais**: Nada criado na raiz
4. **🎯 Específico**: Analisa e adapta automaticamente
5. **♻️ Reutilizável**: Template pode ser usado em N projetos
6. **🛡️ Seguro**: Comandos perigosos sempre bloqueados

## 🚨 **Regras de Segurança**

### ✅ Sempre Permitido

- Comandos de build do projeto (make, npm run, etc.)
- Git seguro (status, diff, log)
- Visualização de arquivos (cat, ls, head)

### ❌ Sempre Bloqueado

- Comandos destrutivos (rm, sudo) - exceto remoção do template
- Download de arquivos (curl, wget)
- Dados sensíveis (_password_, _secret_, _key_)

## 📊 **Métricas de Sucesso**

- **90%+ produtividade** - Desenvolvimento 3-5x mais rápido
- **100% consistência** - Padrões sempre seguidos
- **0 commits acidentais** - Configuração limpa
- **0 arquivos extras** - Projeto limpo após configuração

## 🔄 **Reutilização**

Para usar em outro projeto:

1. Copie esta pasta `copilot-init-template`
2. Execute o comando principal
3. Template será removido automaticamente
4. Projeto fica configurado e limpo

## 💡 **Troubleshooting**

### Template não foi removido?

```bash
# Remova manualmente:
rm -rf copilot-init-template
```

### Configuração não funcionou?

```bash
# Verifique arquivos criados:
ls -la .vscode/
# Deve mostrar: copilot-instructions.md e settings.json
```

### Copilot não reconhece configuração?

```bash
# Recarregue VS Code:
Ctrl+Shift+P → "Developer: Reload Window"
```

---

**🎯 Comando principal**: `@workspace Analise este projeto completamente seguindo copilot-init-template/project-template.instructions.md`

**🧹 Resultado**: Copilot configurado + projeto limpo + template removido!
